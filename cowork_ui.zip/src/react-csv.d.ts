declare module 'react-csv' {
    const CSVLink: any; // Use 'any' as a temporary workaround
    export { CSVLink };
  }